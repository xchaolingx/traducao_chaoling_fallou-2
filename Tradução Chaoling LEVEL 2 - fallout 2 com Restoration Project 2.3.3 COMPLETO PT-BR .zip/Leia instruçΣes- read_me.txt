Essa tradução faz parte do projeto "Tradução Chaoling" onde faça traduções simples usando Google Translator apensar para dar acesso a jogos que não tem tradução de idiomas menos populares de forma oficial ou por comunidades.Se quiser melhorar essa tradução e nos enviar ajudaria muito e daremos todo crédito.

SÓ GARANTIDO FUNCIONAR COM O JOGO ATUALIZADO COM O PATCH "Fallout 2 Restoration Project (version 2.3.3 OU SUPERIOR) "
Esses arquivos foram traduzidos após instalar desse patch acima que com certeza você vai querer instalar pois arruma muito bugs do jogo sem alterar o conteúdo original se você escolher isso na instalação.

Copiar a pasta "English" para a pasta de instalação do jogo "Fallout 2\data\text\" e aceitar  todos arquivos.

Se poder ajudar corrigindo ou melhorar essa tradução teremos o prazer em receber seus arquivos e melhorias em nosso repositório em https://github.com/xchaolingx 


This translation is part of the "Chaoling Translation" project where you can make simple translations using Google Translator to give access to games that don't have less popular language translations officially or by communities. If you want to improve this translation and send us it would help a lot and we will give all credit.

ONLY GUARANTEED TO WORK WITH GAME UPDATED WITH PATCH "Fallout 2 Restoration Project (version 2.3.3 OR HIGHER) "
These files were translated after installing this patch above which you will definitely want to install as it fixes a lot of game bugs without altering the original content if you choose this at installation.

Copy "English" folder to game installation folder "Fallout 2\data\text\" and accept all files.

If you can help by correcting or improving this translation, we will be happy to receive your files and improvements in our repository at https://github.com/xchaolingx 

Cette traduction fait partie du projet "Chaoling Translation" où vous pouvez faire des traductions simples à l'aide de Google Translator pour donner accès à des jeux qui n'ont pas de traductions linguistiques moins populaires officiellement ou par les communautés. Si vous souhaitez améliorer cette traduction et nous l'envoyer , cela aiderait beaucoup et nous donnerons tout le crédit.

UNIQUEMENT GARANTI DE FONCTIONNER AVEC LE JEU MIS À JOUR AVEC LE PATCH "Fallout 2 Restoration Project (version 2.3.3 OU SUPÉRIEURE) "
Ces fichiers ont été traduits après l'installation de ce correctif ci-dessus que vous voudrez certainement installer car il corrige de nombreux bugs du jeu sans altérer le contenu d'origine si vous choisissez cela lors de l'installation.

Copiez le dossier "English" dans le dossier d'installation du jeu "Fallout 2\data\text\" et acceptez tous les fichiers.

Si vous pouvez nous aider en corrigeant ou en améliorant cette traduction, nous serons heureux de recevoir vos fichiers et améliorations dans notre référentiel à l'adresse https://github.com/xchaolinx 

Этот перевод является частью проекта «Chaoling Translation», в котором вы можете делать простые переводы с помощью Google Translator, чтобы предоставить доступ к играм, которые не имеют перевода на менее популярные языки официально или сообществами. Если вы хотите улучшить этот перевод, отправьте его нам , это очень поможет, и мы отдадим все должное.

ГАРАНТИРУЕТСЯ ТОЛЬКО РАБОТА С ИГРОЙ, ОБНОВЛЕННОЙ С ПАТЧОМ «Fallout 2 Restoration Project (версия 2.3.3 ИЛИ выше)»
Эти файлы были переведены после установки вышеупомянутого патча, который вы обязательно захотите установить, поскольку он исправляет множество ошибок в игре без изменения исходного содержимого, если вы выберете это при установке.

Скопируйте папку "English" в папку установки игры "Fallout 2 \ data \ text \" и примите все файлы.

Если вы можете помочь, исправив или улучшив этот перевод, мы будем рады получить ваши файлы и улучшения в нашем репозитории по адресу https://github.com/xchaolingx 


此翻译是“超灵翻译”项目的一部分，您可以使用谷歌翻译器进行简单的翻译，以便访问官方或社区没有不太受欢迎的语言翻译的游戏。如果您想改进此翻译并将其发送给我们，这将有很大帮助，我们将给予所有信任。

仅保证与使用补丁“Fallout 2 Restoration Project（版本 2.3.3 或更高版本）”更新的游戏一起使用
这些文件是在安装此补丁后翻译的，如果您在安装时选择此补丁，您肯定会想要安装它，因为它修复了许多游戏错误而不会改变原始内容。

将“English”文件夹复制到游戏安装文件夹“Fallout 2\data\text\”并接受所有文件。

如果您可以通过更正或改进此翻译提供帮助，我们将很高兴在 https://github.com/xchaolingx 的存储库中收到您的文件和改进 